'use strict';

const restClient = require('..');

describe('rest-client', () => {
    it('needs tests');
});
