# `rest-client`

> TODO: description

## Usage

```
const restClient = require('rest-client');

// TODO: DEMONSTRATE API
```
